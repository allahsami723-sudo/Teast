# Alfarooq Commission Agent Website

A responsive agriculture commission-agent website using separate HTML, CSS and JavaScript files.

## Files
- `index.html` — page structure and content
- `style.css` — black-and-gold responsive styling
- `script.js` — mobile menu, current year, and WhatsApp contact form

## Before publishing
1. Open `script.js` in a text editor.
2. Replace `923001234567` in `WHATSAPP_NUMBER` with your real WhatsApp number. Use country code digits only, without `+`, spaces or dashes.
3. In `index.html`, replace the sample phone number, email, and location with your real business details.
4. Save the files. Double-click `index.html` to preview it in your browser.

## Publish free with GitHub Pages
1. Sign in or create a free account at https://github.com
2. Create a new public repository, for example `alfarooq-commission-agent`.
3. Upload `index.html`, `style.css`, `script.js`, and this README file.
4. Open the repository's **Settings → Pages**.
5. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
6. Wait a few minutes. GitHub will show the live website URL in the Pages section.

You can also use https://www.netlify.com/ and deploy the folder using its manual deploy option. A custom domain is optional and usually costs money; free hosting can provide a free subdomain.

## Notes
- The contact form opens WhatsApp with the visitor's message; it does not store messages on the website.
- Hero and agriculture photos load from Unsplash and therefore require an internet connection.
- Update the sample contact information before making the site public.
