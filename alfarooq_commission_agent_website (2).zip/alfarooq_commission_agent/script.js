// IMPORTANT: Replace the sample WhatsApp number below with your real number.
// Use country code digits only, without +, spaces or dashes (example Pakistan: 923001234567).
const WHATSAPP_NUMBER = "923133508222";

document.getElementById("year").textContent = new Date().getFullYear();

// Update every WhatsApp link from one setting.
document.querySelectorAll("[data-whatsapp]").forEach((link) => {
  link.href = `https://wa.me/${WHATSAPP_NUMBER}`;
});

// Mobile navigation.
const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");

menuToggle.addEventListener("click", () => {
  const isOpen = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.textContent = isOpen ? "✕" : "☰";
});

navLinks.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.textContent = "☰";
  });
});

// Contact form builds a WhatsApp message; no backend or database is required.
document.getElementById("contactForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const name = document.getElementById("name").value.trim();
  const interest = document.getElementById("interest").value;
  const message = document.getElementById("message").value.trim();

  const text = `Assalam-o-Alaikum, Alfarooq Commission Agent.%0A%0AName: ${encodeURIComponent(name)}%0AEnquiry: ${encodeURIComponent(interest)}%0AMessage: ${encodeURIComponent(message)}`;
  window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${text}`, "_blank", "noopener");
});
